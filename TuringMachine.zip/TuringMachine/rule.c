/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   rule.c
 * Author: pochtalionizm
 * 
 * Created on 29 сентября 2017 г., 0:45
 */

#include "rule.h"
